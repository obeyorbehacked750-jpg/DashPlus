const category_icons = {
  "fun": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxZW0iIGhlaWdodD0iMWVtIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjx0aXRsZT5tYWdpYy0zLWxpbmU8L3RpdGxlPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2ZmZmZmZiIgc3Ryb2tlLXdpZHRoPSIyIiBkPSJtNy43NTcgMTAuNTg2bDIuODI5LTIuODI4bTIuODUxLTQuNjYzYy4wNjMtLjEyNy4wNjMtLjEyNy4xMjYgMGwuMDYyLjEyYTIuOTcgMi45NyAwIDAgMCAxLjI5OCAxLjIzNGMuMTAyLjA1MS4xMDMuMDUxIDAgLjEwMmwtLjA5Ni4wNWEyLjk3IDIuOTcgMCAwIDAtMS4yNjQgMS4zMDRjLS4wNjMuMTI3LS4wNjMuMTI3LS4xMjYgMGwtLjA2Mi0uMTJhMi45NyAyLjk3IDAgMCAwLTEuMjk4LTEuMjM0Yy0uMTAzLS4wNTEtLjEwMi0uMDUxIDAtLjEwMmwuMDk2LS4wNWEyLjk3IDIuOTcgMCAwIDAgMS4yNjQtMS4zMDRabTQuNTIxIDQuOTY4Yy4wNDItLjA4NC4wNDItLjA4NC4wODQgMGwuMDQxLjA4YTIgMiAwIDAgMCAuODY2LjgyM2MuMDY4LjAzNC4wNjguMDM0IDAgLjA2OGwtLjA2NC4wMzRhMiAyIDAgMCAwLS44NDMuODY5Yy0uMDQyLjA4NC0uMDQyLjA4NC0uMDg0IDBsLS4wNDEtLjA4YTIgMiAwIDAgMC0uODY2LS44MjNjLS4wNjgtLjAzNC0uMDY4LS4wMzQgMC0uMDY4bC4wNjQtLjAzNGEyIDIgMCAwIDAgLjg0My0uODY5Wk00LjkwNyAxMi42NThjLjA5My0uMjEuMDkzLS4yMS4xODYgMHEuMDQ1LjEwMi4wOTIuMjAxYTQuNyA0LjcgMCAwIDAgMS45MiAyLjA1NmMuMTUyLjA4NS4xNTIuMDg1IDAgLjE3bC0uMTQyLjA4NWE0LjcgNC43IDAgMCAwLTEuODcgMi4xNzJjLS4wOTMuMjEtLjA5My4yMS0uMTg2IDBsLS4wOTItLjIwMWE0LjcgNC43IDAgMCAwLTEuOTItMi4wNTVjLS4xNTItLjA4Ni0uMTUyLS4wODYgMC0uMTcxYTQuNyA0LjcgMCAwIDAgMi4wMTItMi4yNTdabTEyLjc1IDYuNDEzbDEuNDE0LTEuNDE0YTEgMSAwIDAgMCAwLTEuNDE0TDcuNzU3IDQuOTI5YTEgMSAwIDAgMC0xLjQxNCAwTDQuOTMgNi4zNDNhMSAxIDAgMCAwIDAgMS40MTRsMTEuMzE0IDExLjMxNGExIDEgMCAwIDAgMS40MTQgMFoiLz48L3N2Zz4=",
  "gui": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxZW0iIGhlaWdodD0iMWVtIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjx0aXRsZT5tb29uLXN0YXJzLWxpbmU8L3RpdGxlPjxwYXRoIGZpbGw9Im5vbmUiIHN0cm9rZT0iI2ZmZmZmZiIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIgc3Ryb2tlLXdpZHRoPSIyIiBkPSJNNyAxNGE3IDcgMCAwIDAgNi4zODItOS44OGE4IDggMCAxIDEtOS4yNjMgOS4yNjNBNyA3IDAgMCAwIDcgMTMuOTk5WiIvPjxwYXRoIGZpbGw9ImN1cnJlbnRDb2xvciIgZmlsbC1ydWxlPSJldmVub2RkIiBkPSJtOC4zOTcgMi44NTZsLS4xMDIuMjIyYTUuMiA1LjIgMCAwIDEtMi4xMjggMi4yNjRhLjEwOC4xMDggMCAwIDAgMCAuMTg5YTUuMiA1LjIgMCAwIDEgMi4yMyAyLjQ4NmMuMDQuMDg5LjE2Ni4wODkuMjA2IDBsLjEwMi0uMjIyYTUuMiA1LjIgMCAwIDEgMi4xMjctMi4yNjRhLjEwOC4xMDggMCAwIDAgMC0uMTg5bC0uMTU4LS4wOTJhNS4yIDUuMiAwIDAgMS0yLjA3LTIuMzk0YS4xMTMuMTEzIDAgMCAwLS4yMDcgME01LjQzNSA3LjcxNXEtLjAzLjA3LS4wNjQuMTRhMy4yNiAzLjI2IDAgMCAxLTEuMzM2IDEuNDIyYS4wNjguMDY4IDAgMCAwIDAgLjExOGEzLjI3IDMuMjcgMCAwIDEgMS40IDEuNTYyYS4wNzEuMDcxIDAgMCAwIC4xMyAwcS4wMy0uMDcuMDY0LS4xNGEzLjI2IDMuMjYgMCAwIDEgMS4zMzYtMS40MjJhLjA2OC4wNjggMCAwIDAgMC0uMTE4QTMuMjUgMy4yNSAwIDAgMSA1LjYzIDcuODU0bC0uMDY0LS4xMzlhLjA3MS4wNzEgMCAwIDAtLjEzIDAiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg==",
  "customization": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxZW0iIGhlaWdodD0iMWVtIiB2aWV3Qm94PSIwIDAgMjQgMjQiPjx0aXRsZT5wYWludC1icnVzaC1haS1maWxsPC90aXRsZT48cGF0aCBmaWxsPSIjZmZmZmZmIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiIGQ9Ik0xOS40MjIgNS4wNzhjLS4zODQuMTU5LS44LjM0LTEuMjMuNTRjLTEuNDA4LjY1Ny0yLjg2NiAxLjQ4LTMuNzk2IDIuMzY0cS0uMjM2LjIyNS0uNDcuNDkzYy4zNjIuMi43ODIuNDkgMS4xOTUuOTA0Yy40MTQuNDEzLjcwMy44MzMuOTA0IDEuMTk1YTggOCAwIDAgMCAuNDkzLS40N2MuODg0LS45MyAxLjcwNy0yLjM4OCAyLjM2NC0zLjc5N2MuMi0uNDMuMzgtLjg0Ni41NC0xLjIyOW0tNS4wMjUgNi43MWwtLjAzLS4wNjZhMy4zIDMuMyAwIDAgMC0uNjYtLjkzYTMuMyAzLjMgMCAwIDAtLjk5Ni0uNjljLS4yNTkuMzk2LS41MDUuOC0uNzMyIDEuMTlhNSA1IDAgMCAxIDEuMjI4IDEuMjI5Yy4zOTEtLjIyNy43OTUtLjQ3MyAxLjE5LS43MzJtLS4zOSAyLjU4YzEuMjg3LS43MzMgMi44OTUtMS43NjYgMy45Ni0yLjg4NmMxLjExNi0xLjE3NCAyLjA1LTIuODc1IDIuNzI4LTQuMzNhMzUgMzUgMCAwIDAgMS4zMjItMy4yNzhhMS4wOTQgMS4wOTQgMCAwIDAtMS4zOTEtMS4zOTFhMzUgMzUgMCAwIDAtMy4yNzggMS4zMjJjLTEuNDU1LjY3OC0zLjE1NiAxLjYxMi00LjMzIDIuNzI4Yy0xLjEyIDEuMDY1LTIuMTUzIDIuNjczLTIuODg2IDMuOTZhNSA1IDAgMCAwLTQuNTU3IDEuMzZjLS43MDcuNzA5LTEgMS40OS0xLjEzNyAyLjE4Yy0uMDYuMy0uMDg4LjU5Ny0uMTExLjgzOWwtLjAwMi4wMTlhNyA3IDAgMCAxLS4wODQuNjU2Yy0uMTM4LjY4OS0uNjggMS4yNzYtMS4yIDEuNzJjLS4zMDEuMjU4LS41NzguNTAyLS41ODUuOTM3YTEgMSAwIDAgMCAuMzU5Ljc4MmMuOTAyLjc1NCAyLjAxOCAxLjMxNiAzLjEzOCAxLjY0OGMxLjg5LjU2MiA0LjQyNC41NiA2LjY5My0xLjcxYTUgNSAwIDAgMCAxLjM2LTQuNTU2TTYgMWExIDEgMCAwIDEgLjk0Ni42NzdsLjEzLjM3OGEzIDMgMCAwIDAgMS44NjkgMS44N2wuMzc4LjEyOWExIDEgMCAwIDEgMCAxLjg5MmwtLjM3OC4xM2EzIDMgMCAwIDAtMS44NyAxLjg2OWwtLjEyOS4zNzhhMSAxIDAgMCAxLTEuODkyIDBsLS4xMy0uMzc4YTMgMyAwIDAgMC0xLjg2OS0xLjg3bC0uMzc4LS4xMjlhMSAxIDAgMCAxIDAtMS44OTJsLjM3OC0uMTNhMyAzIDAgMCAwIDEuODctMS44NjlsLjEyOS0uMzc4QTEgMSAwIDAgMSA2IDEiIGNsaXAtcnVsZT0iZXZlbm9kZCIvPjwvc3ZnPg=="
};

document.addEventListener('DOMContentLoaded', async () => {
  const container = document.getElementById('addons-list');
  
  const response = await fetch(chrome.runtime.getURL('addons/addons.json'));
  const addons = await response.json();

  chrome.storage.sync.get(['enabledAddons'], (data) => {
    const enabled = data.enabledAddons || [];

    addons.forEach((addon) => {
      const wrapper = document.createElement('div');
      wrapper.className = 'addon';

      const textContainer = document.createElement('div');
      textContainer.className = 'addon-label';

      if (addon.category && category_icons[addon.category]) {
        const icon = document.createElement('img');
        icon.src = category_icons[addon.category];
        icon.className = 'addon-category-icon';
        icon.alt = addon.category;
        textContainer.appendChild(icon);
      }

      const label = document.createElement('h2');
      label.textContent = addon.name;

      const description = document.createElement('label');
      description.textContent = addon.description;

      textContainer.appendChild(label);
      textContainer.appendChild(description);

      const checkbox = document.createElement('input');
      checkbox.type = 'checkbox';
      checkbox.checked = enabled.includes(addon.id);

      checkbox.addEventListener('change', () => {
        chrome.storage.sync.get(['enabledAddons'], (current) => {
          let updated = current.enabledAddons || [];
          if (checkbox.checked) {
            if (!updated.includes(addon.id)) updated.push(addon.id);
          } else {
            updated = updated.filter(id => id !== addon.id);
          }
          chrome.storage.sync.set({ enabledAddons: updated });
        });
      });

      wrapper.appendChild(textContainer);
      wrapper.appendChild(checkbox);
      
      container.appendChild(wrapper);
    });
  });
});