function replace_image(oldUrlPart, newImageUrl) {
  const images = document.querySelectorAll('img');
  let replacedCount = 0;

  images.forEach((img) => {
    const currentSrc = img.src || img.dataset.src || img.currentSrc || '';
    
    if (currentSrc.includes(oldUrlPart)) {
      img.src = newImageUrl;
      img.srcset = '';
      
      if (img.dataset.src) {
        img.dataset.src = newImageUrl;
      }
      
      replacedCount++;
    }
  });
}