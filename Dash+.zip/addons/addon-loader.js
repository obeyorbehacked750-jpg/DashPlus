(async function() {
  try {
    // Getting all data from ADDONS.json
    const response = await fetch(chrome.runtime.getURL('addons/addons.json'));
    const registry = await response.json();
    chrome.storage.sync.get(['enabledAddons'], async (data) => {
      const enabledIds = data.enabledAddons || [];

      for (const addon of registry) {
        if (enabledIds.includes(addon.id)) {
          try {
            const manifestUrl = chrome.runtime.getURL(`addons/${addon.id}/addon.json`);
            const manifest = await (await fetch(manifestUrl)).json();

            if (manifest.userstyles) {
              manifest.userstyles.forEach(style => {
                const link = document.createElement('link');
                link.rel = 'stylesheet';
                link.href = chrome.runtime.getURL(`addons/${addon.id}/${style.url}`);
                document.head.appendChild(link);
              });
            }
            if (manifest.userscripts) {
              manifest.userscripts.forEach(script => {
                const scriptTag = document.createElement('script');
                scriptTag.src = chrome.runtime.getURL(`addons/${addon.id}/${script.url}`);
                document.head.appendChild(scriptTag);
              });
            }
          } catch (err) {
            console.error(err);
          }
        }
      }
    });
  } catch (e) {
    console.error('failed to load check error ', e);
  }
})();